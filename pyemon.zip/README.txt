--your in the READ me file

youtube:pyemon
github:pyemon

--open the testing.bat file to open python to start codeing 
--make sure to NOT del any files
--have a nice codeing bay(: