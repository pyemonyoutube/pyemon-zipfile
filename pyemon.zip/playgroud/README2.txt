start:
--welcome to the playgroud here is were you can code
outside the vid

download:
https://code.visualstudio.com/download


end:
-- you need to have Visual code
--just dont use it for bad 
--bye(: