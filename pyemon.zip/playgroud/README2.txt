start:
--welcome to the playgroud here is were you can code
outside the vid

download:
https://code.visualstudio.com/download
https://notepad-plus-plus.org/downloads/

end:
-- you need to have Visual code
--or notepad
--just dont use it for bad 
--bye(: